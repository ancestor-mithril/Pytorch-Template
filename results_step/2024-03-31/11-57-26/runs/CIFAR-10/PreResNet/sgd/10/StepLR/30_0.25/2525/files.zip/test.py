from scipy.ndimage import binary_fill_holes


def f1(data):
    nonzero_mask = (data[0] != 0)
    for c in range(1, len(data)):
        nonzero_mask |= data[c] != 0
    return binary_fill_holes(nonzero_mask)


def f2(data):
    nonzero_mask = (data[0] != 0).copy()
    for c in range(1, len(data)):
        nonzero_mask |= data[c] != 0
    return binary_fill_holes(nonzero_mask)
